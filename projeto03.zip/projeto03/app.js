const express = require("express");

const router = express.Router()

router.use(express.static('views'))

router.get('/',express.static('./views/index.html'))
router.use('/catalogos',express.static('./views/catalogo.html'))
router.use('/produtos',express.static('./views/produto.html') )
router.use('/contatos',express.static('./views/contato.html') )

router.use(express.static('recursos'))

router.use('/abertura/tipoDocx',express.static('./recursos/arquivo.docx'))
router.use('/abertura/tipoJpeg',express.static('./recursos/arquivo.jpeg'))
router.use('/abertura/tipoMp3',express.static('./recursos/arquivo.mp3'))
router.use('/abertura/tipoMp4',express.static('./recursos/arquivo.mp4'))
router.use('/abertura/tipoJson',express.static('./recursos/arquivo.json'))
router.use('/abertura/tipoMd',express.static('./recursos/arquivo.md'))

const app = express();
app.use('/', router);

module.exports = app; 