const app = require('./app');
app.set('view engine', 'ejs');
app.use(function(req, res, next) {
    res.render('404', { url: req.url })
});

require('dotenv').config({path:'variables.env'});

app.set('port', process.env.PORT || 7777 || 1000 || 8000);
const server = app.listen(app.get('port'),()=>{
    console.log("servidor rodando na porta: "+server.address().port); 
});

  